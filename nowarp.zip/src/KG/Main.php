<?php

namespace KG;

use pocketmine\block\DiamondOre;
use pocketmine\block\ItemFrame;
use pocketmine\command\defaults\HelpCommand;
use pocketmine\inventory\ArmorInventory;
use pocketmine\inventory\Inventory;
use pocketmine\inventory\InventoryHolder;
use pocketmine\item\Armor;
use pocketmine\item\Boat;
use pocketmine\item\Item;
use pocketmine\item\ItemFactory;
use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\TextFormat;

use pocketmine\world\Position;

use pocketmine\player\Player;
use pocketmine\utils\Config;

class Main extends PluginBase{

    public function onEnable(): void{
        @mkdir($this->getDataFolder());
        $this->cfg = new Config($this->getDataFolder()."vl.yml", Config::YAML);

    }
    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool{
        switch ($command->getName()){
            //SETHUB
            case "sethub":
                if ($sender instanceof Player){
                    $pos = $sender->getLocation();
                    $cfg = $this->cfg->getall();
                    if ($this->cfg->exists("hub")){
                        $sender->sendMessage(TextFormat::RED. "Hub ja foi setado!");
                    }else{
                        $this->cfg->set("hub", [
                            "x" => $pos->getX(),
                            "y" => $pos->getY(),
                            "z" => $pos->getZ(),
                            "world" => $pos->getWorld()->getDisplayName()
                        ]);
                        $this->cfg->save();
                        $sender->sendMessage(TextFormat::AQUA."Hub foi setado com sucesso!");
                    }
                }else{
                    $sender->sendMessage(TextFormat::RED. "console nao pode da essa comando!" );
                }
                return true;
            case "hub":
                if ($sender instanceof Player){
                    if ($this->cfg->exists("hub")){
                        $cfg = $this->cfg->getAll();
                        if ($this->getServer()->getWorldManager()->loadWorld($cfg["hub"]["world"]) == false){
                            $sender->sendMessage(TextFormat::RED . "Mundo nao foi encontrado!");
                        }else{
                            $cfg = $this->cfg->getAll();
                            $tp = new Position($cfg["hub"]["x"], $cfg["hub"]["y"],$cfg["hub"]["z"], $this->getServer()->getWorldManager()->getWorldByName($cfg["hub"]["world"]));
                            $sender->teleport($tp);
                            $sender->sendMessage(TextFormat::DARK_GREEN. "Você foi teleportado para Hub!");
                            $sender->sendTitle(TextFormat::YELLOW. "Hub");
                            $sender->sendSubTitle(TextFormat::AQUA. "Você foi teleportado");
                        }
                    }else {
                        $sender->sendMessage(TextFormat::RED. "hub nao foi setado!" );
                    }
                }else{
                    $sender->sendMessage(TextFormat::RED. "console nao pode da essa comando!");
                }
                return true;
            case "unsethub":
               if ($this->cfg->exists("hub")){
                   $sender->sendMessage(TextFormat::DARK_GREEN. "hub foi removido com sucesso!");
                   $this->cfg->remove("hub");
                   $this->cfg->save();
               }else{
                   $sender->sendMessage(TextFormat::RED. "hub nao foi setado!");
               }
               return true;
               //SETPLOTS
            case "setplots":
                if ($sender instanceof Player){
                    $pos = $sender->getLocation();
                    $cfg = $this->cfg->getall();
                    if ($this->cfg->exists("plots")){
                        $sender->sendMessage(TextFormat::RED. "plots ja foi setado!");
                    }else{
                        $this->cfg->set("plots", [
                            "x" => $pos->getX(),
                            "y" => $pos->getY(),
                            "z" => $pos->getZ(),
                            "world" => $pos->getWorld()->getDisplayName()
                        ]);
                        $this->cfg->save();
                        $sender->sendMessage(TextFormat::AQUA."plots foi setado com sucesso!");
                    }
                }else{
                    $sender->sendMessage(TextFormat::RED. "console nao pode da essa comando!" );
                }
                return true;
            case "plots":
                if ($sender instanceof Player){
                    if ($this->cfg->exists("plots")){
                        $cfg = $this->cfg->getAll();
                        if ($this->getServer()->getWorldManager()->loadWorld($cfg["plots"]["world"]) == false){
                            $sender->sendMessage(TextFormat::RED . "Mundo nao foi encontrado!");
                        }else{
                            $cfg = $this->cfg->getAll();
                            $tp = new Position($cfg["plots"]["x"], $cfg["plots"]["y"],$cfg["plots"]["z"], $this->getServer()->getWorldManager()->getWorldByName($cfg["plots"]["world"]));
                            $sender->teleport($tp);
                            $sender->sendMessage(TextFormat::DARK_GREEN. "Você foi teleportado para Plots!");
                            $sender->sendTitle(TextFormat::YELLOW. "Plots");
                            $sender->sendSubTitle(TextFormat::AQUA. "Você foi teleportado");
                        }
                    }else {
                        $sender->sendMessage(TextFormat::RED. "plots nao foi setado!" );
                    }
                }else{
                    $sender->sendMessage(TextFormat::RED. "console nao pode da essa comando!");
                }
                return true;
            case "unsetplots":
                if ($this->cfg->exists("plots")){
                    $sender->sendMessage(TextFormat::DARK_GREEN. "plots foi removido com sucesso!");
                    $this->cfg->remove("plots");
                    $this->cfg->save();
                }else{
                    $sender->sendMessage(TextFormat::RED. "plots nao foi setado!");
                }
                return true;
                //SETVIP
            case "setvip":
                if ($sender instanceof Player){
                    $pos = $sender->getLocation();
                    $cfg = $this->cfg->getall();
                    if ($this->cfg->exists("vip")){
                        $sender->sendMessage(TextFormat::RED. "VIP ja foi setado!");
                    }else{
                        $this->cfg->set("vip", [
                            "x" => $pos->getX(),
                            "y" => $pos->getY(),
                            "z" => $pos->getZ(),
                            "world" => $pos->getWorld()->getDisplayName()
                        ]);
                        $this->cfg->save();
                        $sender->sendMessage(TextFormat::AQUA."VIP foi setado com sucesso!");
                    }
                }else{
                    $sender->sendMessage(TextFormat::RED. "console nao pode da essa comando!" );
                }
                return true;
            case "vip":
                if ($sender instanceof Player){
                    if ($sender->hasPermission('vip.use1')) {
                        if ($this->cfg->exists("vip")) {
                            $cfg = $this->cfg->getAll();
                            if ($this->getServer()->getWorldManager()->loadWorld($cfg["vip"]["world"]) == false) {
                                $sender->sendMessage(TextFormat::RED . "Mundo nao foi encontrado!");
                            } else {
                                $cfg = $this->cfg->getAll();
                                $tp = new Position($cfg["vip"]["x"], $cfg["vip"]["y"], $cfg["vip"]["z"], $this->getServer()->getWorldManager()->getWorldByName($cfg["vip"]["world"]));
                                $sender->teleport($tp);
                                $sender->sendMessage(TextFormat::DARK_GREEN . "Você foi teleportado para VIP!");
                                $sender->sendTitle(TextFormat::YELLOW . "VIP");
                                $sender->sendSubTitle(TextFormat::AQUA . "Você foi teleportado");
                            }
                        } else {
                            $sender->sendMessage(TextFormat::RED . "vip nao foi setado!");
                        }
                    }else{
                        $sender->sendMessage("§cSomente §eVIP§c, §cCompre seu no site: §b kinghide.net");
                    }
                }else{
                    $sender->sendMessage(TextFormat::RED. "console nao pode da essa comando!");
                }
                return true;
            case "unsetvip":
                if ($this->cfg->exists("vip")){
                    $sender->sendMessage(TextFormat::DARK_GREEN. "vip foi removido com sucesso!");
                    $this->cfg->remove("vip");
                    $this->cfg->save();
                }else{
                    $sender->sendMessage(TextFormat::RED. "vip nao foi setado!");
                }
                return true;
                //SETMINAPVP
            case "setminapvp":
                if ($sender instanceof Player){
                    $pos = $sender->getLocation();
                    $cfg = $this->cfg->getall();
                    if ($this->cfg->exists("minapvp")){
                        $sender->sendMessage(TextFormat::RED. "minapvp ja foi setado!");
                    }else{
                        $this->cfg->set("minapvp", [
                            "x" => $pos->getX(),
                            "y" => $pos->getY(),
                            "z" => $pos->getZ(),
                            "world" => $pos->getWorld()->getDisplayName()
                        ]);
                        $this->cfg->save();
                        $sender->sendMessage(TextFormat::AQUA."minapvp foi setado com sucesso!");
                    }
                }else{
                    $sender->sendMessage(TextFormat::RED. "console nao pode da essa comando!" );
                }
                return true;
            case "minapvp":
                if ($sender instanceof Player){
                    if ($this->cfg->exists("minapvp")){
                        $cfg = $this->cfg->getAll();
                        if ($this->getServer()->getWorldManager()->loadWorld($cfg["minapvp"]["world"]) == false){
                            $sender->sendMessage(TextFormat::RED . "Mundo nao foi encontrado!");
                        }else{
                            $cfg = $this->cfg->getAll();
                            $tp = new Position($cfg["minapvp"]["x"], $cfg["minapvp"]["y"],$cfg["minapvp"]["z"], $this->getServer()->getWorldManager()->getWorldByName($cfg["minapvp"]["world"]));
                            $sender->teleport($tp);
                            $sender->sendMessage(TextFormat::DARK_GREEN. "Você foi teleportado para minapvp!");
                            $sender->sendTitle(TextFormat::YELLOW. "MinaPvP");
                            $sender->sendSubTitle(TextFormat::AQUA. "Você foi teleportado");
                        }
                    }else {
                        $sender->sendMessage(TextFormat::RED. "minapvp nao foi setado!" );
                    }
                }else{
                    $sender->sendMessage(TextFormat::RED. "console nao pode da essa comando!");
                }
                return true;
            case "unsetminapvp":
                if ($this->cfg->exists("minapvp")){
                    $sender->sendMessage(TextFormat::DARK_GREEN. "minapvp foi removido com sucesso!");
                    $this->cfg->remove("minapvp");
                    $this->cfg->save();
                }else{
                    $sender->sendMessage(TextFormat::RED. "MinaPvP nao foi setado!");
                }
                return true;
                //SETARENA
            case "setarena":
                if ($sender instanceof Player){
                    $pos = $sender->getLocation();
                    $cfg = $this->cfg->getall();
                    if ($this->cfg->exists("arena")){
                        $sender->sendMessage(TextFormat::RED. "arena ja foi setado!");
                    }else{
                        $this->cfg->set("arena", [
                            "x" => $pos->getX(),
                            "y" => $pos->getY(),
                            "z" => $pos->getZ(),
                            "world" => $pos->getWorld()->getDisplayName()
                        ]);
                        $this->cfg->save();
                        $sender->sendMessage(TextFormat::AQUA."arena foi setado com sucesso!");
                    }
                }else{
                    $sender->sendMessage(TextFormat::RED. "console nao pode da essa comando!" );
                }
                return true;
            case "arena":
                if ($sender instanceof Player){
                    if ($this->cfg->exists("arena")){
                        $cfg = $this->cfg->getAll();
                        if ($this->getServer()->getWorldManager()->loadWorld($cfg["arena"]["world"]) == false){
                            $sender->sendMessage(TextFormat::RED . "Mundo nao foi encontrado!");
                        }else{
                            $cfg = $this->cfg->getAll();
                            $tp = new Position($cfg["arena"]["x"], $cfg["arena"]["y"],$cfg["arena"]["z"], $this->getServer()->getWorldManager()->getWorldByName($cfg["arena"]["world"]));
                            $sender->teleport($tp);
                            $sender->sendMessage(TextFormat::DARK_GREEN. "Você foi teleportado para arena!");
                            $sender->sendTitle(TextFormat::YELLOW. "Arena");
                            $sender->sendSubTitle(TextFormat::AQUA. "Você foi teleportado");
                        }
                    }else {
                        $sender->sendMessage(TextFormat::RED. "arena nao foi setado!" );
                    }
                }else{
                    $sender->sendMessage(TextFormat::RED. "console nao pode da essa comando!");
                }
                return true;
            case "unsetarena":
                if ($this->cfg->exists("arena")){
                    $sender->sendMessage(TextFormat::DARK_GREEN. "arena foi removido com sucesso!");
                    $this->cfg->remove("arena");
                    $this->cfg->save();
                }else{
                    $sender->sendMessage(TextFormat::RED. "arena nao foi setado!");
                }
                return true;
                //SETLOJA
            case "setloja":
                if ($sender instanceof Player){
                    $pos = $sender->getLocation();
                    $cfg = $this->cfg->getall();
                    if ($this->cfg->exists("loja")){
                        $sender->sendMessage(TextFormat::RED. "loja ja foi setado!");
                    }else{
                        $this->cfg->set("loja", [
                            "x" => $pos->getX(),
                            "y" => $pos->getY(),
                            "z" => $pos->getZ(),
                            "world" => $pos->getWorld()->getDisplayName()
                        ]);
                        $this->cfg->save();
                        $sender->sendMessage(TextFormat::AQUA."loja foi setado com sucesso!");
                    }
                }else{
                    $sender->sendMessage(TextFormat::RED. "console nao pode da essa comando!" );
                }
                return true;
            case "loja":
                if ($sender instanceof Player){
                    if ($this->cfg->exists("loja")){
                        $cfg = $this->cfg->getAll();
                        if ($this->getServer()->getWorldManager()->loadWorld($cfg["loja"]["world"]) == false){
                            $sender->sendMessage(TextFormat::RED . "Mundo nao foi encontrado!");
                        }else{
                            $cfg = $this->cfg->getAll();
                            $tp = new Position($cfg["loja"]["x"], $cfg["loja"]["y"],$cfg["loja"]["z"], $this->getServer()->getWorldManager()->getWorldByName($cfg["loja"]["world"]));
                            $sender->teleport($tp);
                            $sender->sendMessage(TextFormat::DARK_GREEN. "Você foi teleportado para loja!");
                            $sender->sendTitle(TextFormat::YELLOW. "Loja");
                            $sender->sendSubTitle(TextFormat::AQUA. "Você foi teleportado");
                        }
                    }else {
                        $sender->sendMessage(TextFormat::RED. "loja nao foi setado!" );
                    }
                }else{
                    $sender->sendMessage(TextFormat::RED. "console nao pode da essa comando!");
                }
                return true;
            case "unsetloja":
                if ($this->cfg->exists("loja")){
                    $sender->sendMessage(TextFormat::DARK_GREEN. "loja foi removido com sucesso!");
                    $this->cfg->remove("loja");
                    $this->cfg->save();
                }else{
                    $sender->sendMessage(TextFormat::RED. "loja nao foi setado!");
                }
                return true;
                //SETEVENTO
            case "setevento":
                if ($sender instanceof Player){
                    $pos = $sender->getLocation();
                    $cfg = $this->cfg->getall();
                    if ($this->cfg->exists("evento")){
                        $sender->sendMessage(TextFormat::RED. "evento ja foi setado!");
                    }else{
                        $this->cfg->set("evento", [
                            "x" => $pos->getX(),
                            "y" => $pos->getY(),
                            "z" => $pos->getZ(),
                            "world" => $pos->getWorld()->getDisplayName()
                        ]);
                        $this->cfg->save();
                        $sender->sendMessage(TextFormat::AQUA."evento foi setado com sucesso!");
                    }
                }else{
                    $sender->sendMessage(TextFormat::RED. "console nao pode da essa comando!" );
                }
                return true;
            case "evento":
                if ($sender instanceof Player){
                    if ($this->cfg->exists("evento")){
                        $cfg = $this->cfg->getAll();
                        if ($this->getServer()->getWorldManager()->loadWorld($cfg["evento"]["world"]) == false){
                            $sender->sendMessage(TextFormat::RED . "Mundo nao foi encontrado!");
                        }else{
                            $cfg = $this->cfg->getAll();
                            $tp = new Position($cfg["evento"]["x"], $cfg["evento"]["y"],$cfg["evento"]["z"], $this->getServer()->getWorldManager()->getWorldByName($cfg["evento"]["world"]));
                            $sender->teleport($tp);
                            $sender->sendMessage(TextFormat::DARK_GREEN. "Você foi teleportado para evento!");
                            $sender->sendTitle(TextFormat::YELLOW. "Evento");
                            $sender->sendSubTitle(TextFormat::AQUA. "Você foi teleportado");
                        }
                    }else {
                        $sender->sendMessage(TextFormat::RED. "evento nao foi setado!" );
                    }
                }else{
                    $sender->sendMessage(TextFormat::RED. "console nao pode da essa comando!");
                }
                return true;
            case "unsetevento":
                if ($this->cfg->exists("evento")){
                    $sender->sendMessage(TextFormat::DARK_GREEN. "evento foi removido com sucesso!");
                    $this->cfg->remove("evento");
                    $this->cfg->save();
                }else{
                    $sender->sendMessage(TextFormat::RED. "evento nao foi setado!");
                }
                return true;
                #boss
            case "setboss":
                if ($sender instanceof Player){
                    $pos = $sender->getLocation();
                    $cfg = $this->cfg->getall();
                    if ($this->cfg->exists("boss")){
                        $sender->sendMessage(TextFormat::RED. "Boss ja foi setado!");
                    }else{
                        $this->cfg->set("boss", [
                            "x" => $pos->getX(),
                            "y" => $pos->getY(),
                            "z" => $pos->getZ(),
                            "world" => $pos->getWorld()->getDisplayName()
                        ]);
                        $this->cfg->save();
                        $sender->sendMessage(TextFormat::AQUA."Boss foi setado com sucesso!");
                    }
                }else{
                    $sender->sendMessage(TextFormat::RED. "console nao pode da essa comando!" );
                }
                return true;
            case "boss":
                if ($sender instanceof Player){
                    if ($this->cfg->exists("boss")){
                        $cfg = $this->cfg->getAll();
                        if ($this->getServer()->getWorldManager()->loadWorld($cfg["boss"]["world"]) == false){
                            $sender->sendMessage(TextFormat::RED . "Mundo nao foi encontrado!");
                        }else{
                            $cfg = $this->cfg->getAll();
                            $tp = new Position($cfg["boss"]["x"], $cfg["boss"]["y"],$cfg["boss"]["z"], $this->getServer()->getWorldManager()->getWorldByName($cfg["boss"]["world"]));
                            $sender->teleport($tp);
                            $sender->sendMessage(TextFormat::DARK_GREEN. "Você foi teleportado para hub!");
                            $sender->sendTitle(TextFormat::YELLOW. "Boss");
                            $sender->sendSubTitle(TextFormat::AQUA. "Você foi teleportado");
                        }
                    }else {
                        $sender->sendMessage(TextFormat::RED. "hub nao foi setado!" );
                    }
                }else{
                    $sender->sendMessage(TextFormat::RED. "console nao pode da essa comando!");
                }
                return true;
            case "unsetboss":
                if ($this->cfg->exists("boss")){
                    $sender->sendMessage(TextFormat::DARK_GREEN. "Boss foi removido com sucesso!");
                    $this->cfg->remove("boss");
                    $this->cfg->save();
                }else{
                    $sender->sendMessage(TextFormat::RED. "Boss nao foi setado!");
                }
                return true;
        }
        return true;
    }
}
